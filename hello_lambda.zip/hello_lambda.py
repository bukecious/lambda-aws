# def handler(event, context):
#     return { "message": "Hello, World!" }

# def post_handler(event, context):
#     return { "message": "I should have created something..." }

def post_handler(event, context):
    return{
        "first_name": "bukola",
        "last_name": "Johnson",
        "code": "123",
        "phone_number":"08033678361"
    }
    
